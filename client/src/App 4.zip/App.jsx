import { useState, useEffect, useCallback } from "react";

const generateCode = () => {
  const chars = 'abcdefghjkmnpqrstuvwxyz23456789';
  const seg = () => Array.from({ length: 4 }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
  return `${seg()}-${seg()}-${seg()}`;
};

const useIsMobile = () => {
  const [mobile, setMobile] = useState(window.innerWidth < 768);
  useEffect(() => {
    const fn = () => setMobile(window.innerWidth < 768);
    window.addEventListener('resize', fn);
    return () => window.removeEventListener('resize', fn);
  }, []);
  return mobile;
};

const CheckIco = () => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round" style={{ width: 13, height: 13 }}><path d="M20 6 9 17l-5-5" /></svg>;
const TrashIco = () => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" style={{ width: 14, height: 14 }}><polyline points="3 6 5 6 21 6" /><path d="M19 6l-1 14H6L5 6" /><path d="M10 11v6m4-6v6" /><path d="M9 6V4h6v2" /></svg>;
const PencilIco = () => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" style={{ width: 13, height: 13 }}><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" /><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" /></svg>;
const CopyIco = () => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" style={{ width: 13, height: 13 }}><rect x="9" y="9" width="13" height="13" rx="2" /><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" /></svg>;
const RefreshIco = () => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" style={{ width: 13, height: 13 }}><path d="M23 4v6h-6" /><path d="M1 20v-6h6" /><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15" /></svg>;
const BackIco = () => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" style={{ width: 18, height: 18 }}><path d="M19 12H5M12 5l-7 7 7 7" /></svg>;
const FolderIco = () => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" style={{ width: 15, height: 15 }}><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z" /></svg>;
const SpinIco = () => <svg style={{ width: 15, height: 15, animation: 'spin 1s linear infinite' }} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}><circle cx="12" cy="12" r="10" strokeOpacity=".2" /><path d="M12 2a10 10 0 0 1 10 10" strokeLinecap="round" /></svg>;

export default function App() {
  const [screen, setScreen] = useState('home');
  const [adminPassword, setAdminPassword] = useState('');
  const [clientProject, setClientProject] = useState(null);

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600;700&family=DM+Mono:wght@400;500&display=swap');
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        html { height: -webkit-fill-available; }
        body { background: #0f1117; color: #e2e8f0; font-family: 'DM Sans', system-ui, sans-serif; -webkit-tap-highlight-color: transparent; min-height: 100vh; min-height: -webkit-fill-available; overflow-x: hidden; }
        @keyframes spin { to { transform: rotate(360deg); } }
        @keyframes shake { 0%,100%{transform:translateX(0)} 20%{transform:translateX(-6px)} 40%{transform:translateX(6px)} 60%{transform:translateX(-4px)} 80%{transform:translateX(4px)} }
        input, textarea, button { font-family: inherit; }
        input::placeholder, textarea::placeholder { color: #3d4455; }
        input:focus, textarea:focus { outline: none; }
        ::-webkit-scrollbar { width: 3px; }
        ::-webkit-scrollbar-thumb { background: #2a3245; border-radius: 2px; }
        .task-row:hover .task-actions { opacity: 1 !important; }
      `}</style>
      {screen === 'home' && <HomeView onAdmin={p => { setAdminPassword(p); setScreen('admin'); }} onClient={proj => { setClientProject(proj); setScreen('client'); }} />}
      {screen === 'admin' && <AdminView adminPassword={adminPassword} onLogout={() => { setAdminPassword(''); setScreen('home'); }} />}
      {screen === 'client' && <ClientView project={clientProject} onLogout={() => { setClientProject(null); setScreen('home'); }} />}
    </>
  );
}

function HomeView({ onAdmin, onClient }) {
  const [tab, setTab] = useState('client');
  const [adminPass, setAdminPass] = useState('');
  const [clientCode, setClientCode] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [shake, setShake] = useState(false);

  const triggerError = msg => { setError(msg); setShake(true); setTimeout(() => setShake(false), 500); };

  const handleAdmin = async () => {
    if (!adminPass) return;
    setLoading(true);
    const res = await fetch('/api/auth/admin', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ password: adminPass }) }).then(r => r.json());
    setLoading(false);
    if (res.ok) onAdmin(adminPass); else triggerError('Pogrešna lozinka.');
  };

  const handleClient = async () => {
    if (!clientCode) return;
    setLoading(true);
    const res = await fetch('/api/auth/client', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ code: clientCode }) }).then(r => r.json());
    setLoading(false);
    if (res.ok) onClient(res.project); else triggerError('Pristupni kod nije ispravan.');
  };

  const s = { card: '#151921', border: '#1e2330', muted: '#4a5568', text: '#e2e8f0', accent: '#3b82f6' };
  return (
    <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}>
      <div style={{ width: '100%', maxWidth: 380 }}>
        <div style={{ textAlign: 'center', marginBottom: 32 }}>
          <div style={{ marginBottom: 10 }}>
            <img src="https://prplus.hr/logo.png" alt="PR Plus" style={{ height: 32, width: 'auto', filter: 'brightness(0) invert(1)' }} />
          </div>
          <p style={{ fontSize: 13, color: s.muted }}>Praćenje projekata</p>
        </div>
        <div style={{ animation: shake ? 'shake 0.4s ease' : 'none', background: s.card, border: `1px solid ${s.border}`, borderRadius: 18, overflow: 'hidden' }}>
          <div style={{ display: 'flex', borderBottom: `1px solid ${s.border}` }}>
            {[['client', 'Klijentski pristup'], ['admin', 'Admin']].map(([t, label]) => (
              <button key={t} onClick={() => { setTab(t); setError(''); }}
                style={{ flex: 1, padding: '14px 0', fontSize: 13, fontWeight: 500, border: 'none', cursor: 'pointer', background: tab === t ? '#1e2330' : 'transparent', color: tab === t ? s.text : s.muted, borderBottom: tab === t ? `2px solid ${s.accent}` : '2px solid transparent' }}>
                {label}
              </button>
            ))}
          </div>
          <div style={{ padding: 24 }}>
            {tab === 'client' ? <>
              <p style={{ fontSize: 13, color: s.muted, marginBottom: 16 }}>Unesite pristupni kod koji ste dobili od webmastera.</p>
              <input type="text" placeholder="Pristupni kod" value={clientCode} onChange={e => { setClientCode(e.target.value); setError(''); }} onKeyDown={e => e.key === 'Enter' && handleClient()}
                style={{ width: '100%', background: '#1e2330', border: `1px solid ${s.border}`, borderRadius: 10, padding: '12px 14px', fontSize: 14, color: s.text, fontFamily: "'DM Mono',monospace", letterSpacing: '0.06em', marginBottom: 6 }} />
              {error && <p style={{ fontSize: 12, color: '#f87171', marginBottom: 10 }}>{error}</p>}
              {!error && <div style={{ height: 16 }} />}
              <button onClick={handleClient} disabled={loading} style={{ width: '100%', padding: '13px 0', borderRadius: 10, border: 'none', cursor: 'pointer', background: 'linear-gradient(135deg,#3b82f6,#6366f1)', color: 'white', fontSize: 14, fontWeight: 600, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8 }}>
                {loading && <SpinIco />} Otvori projekt
              </button>
            </> : <>
              <p style={{ fontSize: 13, color: s.muted, marginBottom: 16 }}>Admin pristup za upravljanje projektima.</p>
              <input type="password" placeholder="Lozinka" value={adminPass} onChange={e => { setAdminPass(e.target.value); setError(''); }} onKeyDown={e => e.key === 'Enter' && handleAdmin()}
                style={{ width: '100%', background: '#1e2330', border: `1px solid ${s.border}`, borderRadius: 10, padding: '12px 14px', fontSize: 14, color: s.text, marginBottom: 6 }} />
              {error && <p style={{ fontSize: 12, color: '#f87171', marginBottom: 10 }}>{error}</p>}
              {!error && <div style={{ height: 16 }} />}
              <button onClick={handleAdmin} disabled={loading} style={{ width: '100%', padding: '13px 0', borderRadius: 10, border: 'none', cursor: 'pointer', background: '#1e2330', color: s.text, fontSize: 14, fontWeight: 600, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8 }}>
                {loading && <SpinIco />} Prijavi se
              </button>
              <p style={{ fontSize: 11, color: '#252d3d', textAlign: 'center', marginTop: 14 }}>zadana lozinka: admin2024</p>
            </>}
          </div>
        </div>
      </div>
    </div>
  );
}

function AdminView({ adminPassword, onLogout }) {
  const isMobile = useIsMobile();
  const [projects, setProjects] = useState([]);
  const [selectedId, setSelectedId] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showNew, setShowNew] = useState(false);
  const [newForm, setNewForm] = useState({ name: '', clientName: '', accessCode: generateCode(), description: '' });
  const [newCodeCopied, setNewCodeCopied] = useState(false);
  const [newTask, setNewTask] = useState('');
  const [editNote, setEditNote] = useState(null);
  const [editProject, setEditProject] = useState(null);
  const [showSettings, setShowSettings] = useState(false);
  const [passForms, setPassForms] = useState({ current: '', next: '' });
  const [passError, setPassError] = useState('');
  const [projCodeCopied, setProjCodeCopied] = useState(false);
  const [apiError, setApiError] = useState('');

  const proj = projects.find(p => p.id === selectedId);
  const done = proj ? proj.tasks.filter(t => t.done).length : 0;
  const total = proj ? proj.tasks.length : 0;
  const pct = total > 0 ? Math.round((done / total) * 100) : 0;

  const h = (adminPassword) => ({ 'Content-Type': 'application/json', 'x-admin-password': adminPassword });

  const loadProjects = useCallback(async () => {
    setLoading(true);
    const data = await fetch('/api/projects', { headers: { 'x-admin-password': adminPassword } }).then(r => r.json());
    if (Array.isArray(data)) setProjects(data);
    setLoading(false);
  }, [adminPassword]);

  useEffect(() => { loadProjects(); }, [loadProjects]);

  const createProject = async () => {
    if (!newForm.name.trim() || !newForm.accessCode.trim()) return;
    const data = await fetch('/api/projects', { method: 'POST', headers: h(adminPassword), body: JSON.stringify(newForm) }).then(r => r.json());
    if (data.error) { setApiError(data.error); return; }
    setProjects(ps => [data, ...ps]);
    setSelectedId(data.id);
    setShowNew(false);
    setNewForm({ name: '', clientName: '', accessCode: generateCode(), description: '' });
  };

  const saveEditProject = async () => {
    if (!editProject) return;
    const data = await fetch(`/api/projects/${selectedId}`, { method: 'PUT', headers: h(adminPassword), body: JSON.stringify(editProject) }).then(r => r.json());
    if (data.error) { setApiError(data.error); return; }
    setProjects(ps => ps.map(p => p.id === data.id ? data : p));
    setEditProject(null);
  };

  const deleteProject = async () => {
    if (!proj || !confirm(`Obrisati projekt "${proj.name}"?`)) return;
    await fetch(`/api/projects/${selectedId}`, { method: 'DELETE', headers: { 'x-admin-password': adminPassword } });
    setProjects(ps => ps.filter(p => p.id !== selectedId));
    setSelectedId(null);
  };

  const addTask = async () => {
    if (!newTask.trim() || !proj) return;
    const task = await fetch(`/api/projects/${selectedId}/tasks`, { method: 'POST', headers: h(adminPassword), body: JSON.stringify({ text: newTask }) }).then(r => r.json());
    if (!task.error) { setProjects(ps => ps.map(p => p.id === selectedId ? { ...p, tasks: [...p.tasks, task] } : p)); setNewTask(''); }
  };

  const toggleTask = async (tid, cur) => {
    const task = await fetch(`/api/tasks/${tid}`, { method: 'PUT', headers: h(adminPassword), body: JSON.stringify({ done: !cur }) }).then(r => r.json());
    if (!task.error) setProjects(ps => ps.map(p => p.id === selectedId ? { ...p, tasks: p.tasks.map(t => t.id === tid ? task : t) } : p));
  };

  const saveNote = async (tid) => {
    const task = await fetch(`/api/tasks/${tid}`, { method: 'PUT', headers: h(adminPassword), body: JSON.stringify({ note: editNote.text }) }).then(r => r.json());
    if (!task.error) setProjects(ps => ps.map(p => p.id === selectedId ? { ...p, tasks: p.tasks.map(t => t.id === tid ? task : t) } : p));
    setEditNote(null);
  };

  const deleteTask = async (tid) => {
    await fetch(`/api/tasks/${tid}`, { method: 'DELETE', headers: { 'x-admin-password': adminPassword } });
    setProjects(ps => ps.map(p => p.id === selectedId ? { ...p, tasks: p.tasks.filter(t => t.id !== tid) } : p));
  };

  const changePassword = async () => {
    setPassError('');
    const data = await fetch('/api/settings/password', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ currentPassword: passForms.current, newPassword: passForms.next }) }).then(r => r.json());
    if (data.ok) { setShowSettings(false); setPassForms({ current: '', next: '' }); alert('Lozinka promijenjena.'); }
    else setPassError(data.error || 'Greška.');
  };

  const copy = (text, setter) => { navigator.clipboard.writeText(text); setter(true); setTimeout(() => setter(false), 2000); };

  const s = { bg: '#0f1117', sidebar: '#0d1018', card: '#151921', border: '#1e2330', text: '#e2e8f0', muted: '#4a5568', accent: '#3b82f6', green: '#22c55e', red: '#ef4444', mono: "'DM Mono',monospace" };

  const inputStyle = { width: '100%', background: '#1e2330', border: `1px solid ${s.border}`, borderRadius: 8, padding: '10px 12px', fontSize: 14, color: s.text, marginBottom: 8 };

  // ── Reusable: Code row with refresh + copy ────────────────────────────────
  const CodeRow = ({ value, onChange, copied, onCopy, onRefresh }) => (
    <div>
      <p style={{ fontSize: 11, color: s.muted, marginBottom: 5 }}>Pristupni kod za klijenta</p>
      <div style={{ display: 'flex', gap: 6, marginBottom: 4 }}>
        <input value={value} onChange={e => onChange(e.target.value)} placeholder="Pristupni kod"
          style={{ flex: 1, background: '#1e2330', border: `1px solid ${s.border}`, borderRadius: 8, padding: '10px 12px', fontSize: 13, color: '#60a5fa', fontFamily: s.mono, letterSpacing: '0.05em' }} />
        <button onClick={onRefresh} title="Novi kod"
          style={{ background: '#1e2330', border: `1px solid ${s.border}`, borderRadius: 8, padding: '0 11px', color: s.muted, cursor: 'pointer', display: 'flex', alignItems: 'center' }}><RefreshIco /></button>
        <button onClick={onCopy} title="Kopiraj"
          style={{ background: copied ? '#0d2516' : '#1e3a5f', border: `1px solid ${copied ? '#1a4030' : '#1e4a7a'}`, borderRadius: 8, padding: '0 13px', color: copied ? s.green : '#60a5fa', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 5, fontSize: 12, fontWeight: 600, whiteSpace: 'nowrap' }}>
          {copied ? <CheckIco /> : <CopyIco />}{copied ? 'Kopirano' : 'Kopiraj'}
        </button>
      </div>
      <p style={{ fontSize: 10, color: '#252d3d', marginBottom: 10 }}>Auto-generiran · možeš promijeniti</p>
    </div>
  );

  // ── New project panel ─────────────────────────────────────────────────────
  const NewProjectPanel = () => (
    <div style={{ padding: isMobile ? 16 : '0 10px 10px', ...(isMobile ? {} : {}) }}>
      <div style={{ background: s.card, border: `1px solid ${s.border}`, borderRadius: 12, padding: 14 }}>
        <p style={{ fontSize: 11, fontWeight: 700, color: s.muted, marginBottom: 10, textTransform: 'uppercase', letterSpacing: '0.06em' }}>Novi projekt</p>
        {[{ ph: 'Naziv projekta *', key: 'name' }, { ph: 'Ime klijenta', key: 'clientName' }, { ph: 'Kratki opis', key: 'description' }].map(({ ph, key }) => (
          <input key={key} placeholder={ph} value={newForm[key]} onChange={e => setNewForm(f => ({ ...f, [key]: e.target.value }))}
            style={{ ...inputStyle, fontSize: 13, padding: '9px 10px' }} />
        ))}
        <CodeRow value={newForm.accessCode} onChange={v => setNewForm(f => ({ ...f, accessCode: v }))}
          copied={newCodeCopied} onCopy={() => copy(newForm.accessCode, setNewCodeCopied)}
          onRefresh={() => setNewForm(f => ({ ...f, accessCode: generateCode() }))} />
        <div style={{ display: 'flex', gap: 7 }}>
          <button onClick={createProject} style={{ flex: 1, background: s.accent, color: 'white', border: 'none', borderRadius: 8, padding: '10px 0', fontSize: 13, fontWeight: 700, cursor: 'pointer' }}>Kreiraj</button>
          <button onClick={() => setShowNew(false)} style={{ flex: 1, background: '#1e2330', color: s.muted, border: 'none', borderRadius: 8, padding: '10px 0', fontSize: 13, cursor: 'pointer' }}>Odustani</button>
        </div>
      </div>
    </div>
  );

  // ── Project list ──────────────────────────────────────────────────────────
  const ProjectList = () => (
    <div style={{ overflowY: 'auto', flex: 1, paddingBottom: isMobile ? 80 : 0 }}>
      {loading && <p style={{ fontSize: 13, color: s.muted, textAlign: 'center', padding: 24 }}>Učitavanje...</p>}
      {!loading && projects.length === 0 && <p style={{ fontSize: 13, color: s.muted, textAlign: 'center', padding: 24 }}>Nema projekata.</p>}
      {projects.map(p => {
        const d2 = p.tasks.filter(t => t.done).length, t2 = p.tasks.length;
        const active = selectedId === p.id;
        return (
          <div key={p.id} onClick={() => setSelectedId(p.id)}
            style={{ padding: isMobile ? '14px 16px' : '11px 12px', cursor: 'pointer', borderLeft: !isMobile && active ? `2px solid ${s.accent}` : '2px solid transparent', background: active && !isMobile ? '#12161e' : 'transparent', borderBottom: isMobile ? `1px solid ${s.border}` : 'none' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 7, marginBottom: 2 }}>
              <FolderIco />
              <span style={{ fontSize: isMobile ? 15 : 13, fontWeight: 500, color: active && !isMobile ? s.text : '#9aa5b8', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{p.name}</span>
            </div>
            {p.client_name && <p style={{ fontSize: 12, color: s.muted, marginLeft: 22, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{p.client_name}</p>}
            <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 6, marginLeft: 22 }}>
              <div style={{ flex: 1, height: 3, background: '#1e2330', borderRadius: 2, overflow: 'hidden' }}>
                <div style={{ width: `${t2 > 0 ? (d2 / t2) * 100 : 0}%`, height: '100%', background: s.green }} />
              </div>
              <span style={{ fontSize: 11, color: s.muted }}>{d2}/{t2}</span>
            </div>
          </div>
        );
      })}
    </div>
  );

  // ── Project detail ────────────────────────────────────────────────────────
  const ProjectDetail = () => !proj ? null : (
    <div style={{ overflowY: 'auto', flex: 1, padding: isMobile ? '16px 16px 100px' : 20 }}>
      <div style={{ maxWidth: 680, margin: '0 auto' }}>

        {/* Header card */}
        <div style={{ background: s.card, border: `1px solid ${s.border}`, borderRadius: 14, padding: isMobile ? 16 : 20, marginBottom: 14 }}>
          {editProject ? (
            <div>
              <p style={{ fontSize: 11, fontWeight: 700, color: s.muted, textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 10 }}>Uredi projekt</p>
              {[{ ph: 'Naziv projekta', key: 'name' }, { ph: 'Ime klijenta', key: 'clientName' }, { ph: 'Kratki opis', key: 'description' }].map(({ ph, key }) => (
                <input key={key} placeholder={ph} value={editProject[key] || ''} onChange={e => setEditProject(ep => ({ ...ep, [key]: e.target.value }))} style={inputStyle} />
              ))}
              <CodeRow value={editProject.accessCode || ''} onChange={v => setEditProject(ep => ({ ...ep, accessCode: v }))}
                copied={projCodeCopied} onCopy={() => copy(editProject.accessCode, setProjCodeCopied)}
                onRefresh={() => setEditProject(ep => ({ ...ep, accessCode: generateCode() }))} />
              <div style={{ display: 'flex', gap: 8 }}>
                <button onClick={saveEditProject} style={{ flex: 1, background: s.accent, color: 'white', border: 'none', borderRadius: 8, padding: '10px 0', fontSize: 13, fontWeight: 700, cursor: 'pointer' }}>Spremi</button>
                <button onClick={() => setEditProject(null)} style={{ flex: 1, background: '#1e2330', color: s.muted, border: 'none', borderRadius: 8, padding: '10px 0', fontSize: 13, cursor: 'pointer' }}>Odustani</button>
              </div>
            </div>
          ) : (<>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 10, marginBottom: 14 }}>
              <div style={{ flex: 1, minWidth: 0 }}>
                <h2 style={{ fontSize: isMobile ? 17 : 19, fontWeight: 700, marginBottom: 2, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{proj.name}</h2>
                {proj.client_name && <p style={{ fontSize: 13, color: s.muted }}>{proj.client_name}</p>}
                {proj.description && <p style={{ fontSize: 12, color: '#5a6070', marginTop: 3 }}>{proj.description}</p>}
              </div>
              <div style={{ display: 'flex', gap: 6, flexShrink: 0 }}>
                <button onClick={() => setEditProject({ name: proj.name, clientName: proj.client_name, accessCode: proj.access_code, description: proj.description })}
                  style={{ background: 'transparent', border: `1px solid ${s.border}`, borderRadius: 8, padding: '7px 12px', fontSize: 12, color: s.muted, cursor: 'pointer' }}>Uredi</button>
                <button onClick={deleteProject}
                  style={{ background: 'transparent', border: '1px solid #2a1a1a', borderRadius: 8, padding: '7px 12px', fontSize: 12, color: s.red, cursor: 'pointer' }}>Briši</button>
              </div>
            </div>

            {/* Code block */}
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, background: '#0d1625', border: '1px solid #1a2a40', borderRadius: 10, padding: '11px 14px', marginBottom: 14 }}>
              <div style={{ flex: 1, minWidth: 0 }}>
                <p style={{ fontSize: 10, color: s.muted, textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 2 }}>Pristupni kod za klijenta</p>
                <p style={{ fontSize: 16, fontWeight: 700, fontFamily: s.mono, color: '#60a5fa', letterSpacing: '0.1em' }}>{proj.access_code}</p>
              </div>
              <button onClick={() => copy(proj.access_code, setProjCodeCopied)}
                style={{ background: projCodeCopied ? '#0d2516' : '#1e3a5f', border: `1px solid ${projCodeCopied ? '#1a4030' : '#2a5080'}`, borderRadius: 8, padding: '9px 16px', fontSize: 13, fontWeight: 600, color: projCodeCopied ? s.green : '#60a5fa', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6, whiteSpace: 'nowrap' }}>
                {projCodeCopied ? <CheckIco /> : <CopyIco />}{projCodeCopied ? 'Kopirano!' : 'Kopiraj kod'}
              </button>
            </div>

            {/* Progress */}
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
              <span style={{ fontSize: 12, color: s.muted }}>{done}/{total} zadataka</span>
              <span style={{ fontSize: 12, fontWeight: 700, color: pct === 100 ? s.green : s.text }}>{pct}%</span>
            </div>
            <div style={{ height: 4, background: '#1e2330', borderRadius: 2, overflow: 'hidden' }}>
              <div style={{ width: `${pct}%`, height: '100%', background: pct === 100 ? s.green : 'linear-gradient(90deg,#3b82f6,#6366f1)', transition: 'width 0.4s', borderRadius: 2 }} />
            </div>
          </>)}
        </div>

        {/* Add task */}
        <div style={{ display: 'flex', gap: 8, marginBottom: 14 }}>
          <input placeholder="Dodaj zadatak... (Enter)" value={newTask} onChange={e => setNewTask(e.target.value)} onKeyDown={e => e.key === 'Enter' && addTask()}
            style={{ flex: 1, background: s.card, border: `1px solid ${s.border}`, borderRadius: 10, padding: '12px 14px', fontSize: 14, color: s.text }} />
          <button onClick={addTask} style={{ background: s.accent, color: 'white', border: 'none', borderRadius: 10, padding: '0 18px', fontSize: 13, fontWeight: 700, cursor: 'pointer' }}>Dodaj</button>
        </div>

        {/* Tasks */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {proj.tasks.length === 0 && (
            <div style={{ background: s.card, border: `1px dashed ${s.border}`, borderRadius: 12, padding: 40, textAlign: 'center' }}>
              <p style={{ fontSize: 13, color: s.muted }}>Nema zadataka. Dodaj prvi zadatak gore.</p>
            </div>
          )}
          {proj.tasks.map(task => (
            <div key={task.id} className="task-row"
              style={{ background: task.done ? '#0d1a12' : s.card, border: `1px solid ${task.done ? '#1a3025' : s.border}`, borderRadius: 10, padding: '13px 14px' }}>
              <div style={{ display: 'flex', alignItems: 'flex-start', gap: 10 }}>
                <button onClick={() => toggleTask(task.id, task.done)}
                  style={{ width: 24, height: 24, borderRadius: 7, flexShrink: 0, border: `2px solid ${task.done ? s.green : '#2a3245'}`, background: task.done ? s.green : 'transparent', display: 'flex', alignItems: 'center', justifyContent: 'center', marginTop: 1, color: 'white', cursor: 'pointer', transition: 'all 0.15s' }}>
                  {task.done && <CheckIco />}
                </button>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <p style={{ fontSize: 14, color: task.done ? s.muted : s.text, textDecoration: task.done ? 'line-through' : 'none', lineHeight: 1.5 }}>{task.text}</p>
                  {task.note && editNote?.taskId !== task.id && (
                    <p style={{ fontSize: 13, color: '#60a5fa', marginTop: 6, background: '#0f1e35', padding: '6px 10px', borderRadius: 6, borderLeft: '2px solid #3b82f6', lineHeight: 1.4 }}>{task.note}</p>
                  )}
                  {editNote?.taskId === task.id && (
                    <div style={{ marginTop: 8 }}>
                      <textarea value={editNote.text} onChange={e => setEditNote(en => ({ ...en, text: e.target.value }))} rows={2} placeholder="Bilješka za klijenta..."
                        style={{ width: '100%', background: '#1e2330', border: `1px solid ${s.border}`, borderRadius: 7, padding: '8px 10px', fontSize: 13, color: s.text, resize: 'none' }} />
                      <div style={{ display: 'flex', gap: 6, marginTop: 6 }}>
                        <button onClick={() => saveNote(task.id)} style={{ background: s.accent, color: 'white', border: 'none', borderRadius: 6, padding: '7px 16px', fontSize: 13, fontWeight: 700, cursor: 'pointer' }}>Spremi</button>
                        <button onClick={() => setEditNote(null)} style={{ background: '#1e2330', color: s.muted, border: 'none', borderRadius: 6, padding: '7px 16px', fontSize: 13, cursor: 'pointer' }}>Odustani</button>
                      </div>
                    </div>
                  )}
                </div>
                {isMobile ? (
                  <div style={{ display: 'flex', gap: 6, flexShrink: 0 }}>
                    <button onClick={() => setEditNote({ taskId: task.id, text: task.note || '' })}
                      style={{ background: '#1e2330', border: 'none', color: s.muted, width: 34, height: 34, borderRadius: 8, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><PencilIco /></button>
                    <button onClick={() => deleteTask(task.id)}
                      style={{ background: '#1e0a0a', border: 'none', color: '#7a2020', width: 34, height: 34, borderRadius: 8, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><TrashIco /></button>
                  </div>
                ) : (
                  <div className="task-actions" style={{ display: 'flex', gap: 4, flexShrink: 0, opacity: 0, transition: 'opacity 0.15s' }}>
                    <button onClick={() => setEditNote({ taskId: task.id, text: task.note || '' })}
                      style={{ background: 'transparent', border: 'none', color: s.muted, padding: '4px 8px', borderRadius: 6, fontSize: 11, display: 'flex', alignItems: 'center', gap: 4, cursor: 'pointer' }}>
                      <PencilIco /> {task.note ? 'Uredi' : 'Bilj.'}
                    </button>
                    <button onClick={() => deleteTask(task.id)}
                      style={{ background: 'transparent', border: 'none', color: '#5a2020', padding: '4px 8px', borderRadius: 6, cursor: 'pointer', display: 'flex', alignItems: 'center' }}><TrashIco /></button>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const Header = ({ showBack }) => (
    <div style={{ height: 52, display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 16px', background: s.sidebar, borderBottom: `1px solid ${s.border}`, flexShrink: 0 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, flex: 1, minWidth: 0 }}>
        {showBack && (
          <button onClick={() => setSelectedId(null)} style={{ background: 'transparent', border: 'none', color: s.muted, cursor: 'pointer', display: 'flex', alignItems: 'center', padding: '4px 8px 4px 0', marginRight: 2 }}>
            <BackIco />
          </button>
        )}
        <img src="https://prplus.hr/logo.png" alt="PR Plus" style={{ height: 22, width: 'auto', filter: 'brightness(0) invert(1)', flexShrink: 0 }} />
        {!showBack
          ? <span style={{ fontSize: 11, color: s.muted, background: '#1e2330', padding: '2px 8px', borderRadius: 10 }}>admin</span>
          : <span style={{ fontWeight: 600, fontSize: 14, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{proj?.name}</span>
        }
      </div>
      <div style={{ display: 'flex', gap: 4, flexShrink: 0 }}>
        {!showBack && <button onClick={() => setShowSettings(!showSettings)} style={{ background: 'transparent', border: 'none', fontSize: 12, color: s.muted, padding: '4px 10px', borderRadius: 6, cursor: 'pointer' }}>Postavke</button>}
        <button onClick={onLogout} style={{ background: 'transparent', border: 'none', fontSize: 12, color: s.muted, padding: '4px 10px', borderRadius: 6, cursor: 'pointer' }}>Odjava</button>
      </div>
    </div>
  );

  const SettingsBar = () => showSettings ? (
    <div style={{ background: '#1a1408', borderBottom: '1px solid #332a10', padding: '10px 16px', display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap', flexShrink: 0 }}>
      <span style={{ fontSize: 12, color: '#d4a017' }}>Nova lozinka:</span>
      <input type="password" placeholder="Trenutna" value={passForms.current} onChange={e => setPassForms(f => ({ ...f, current: e.target.value }))}
        style={{ background: '#231c08', border: '1px solid #3d3010', borderRadius: 6, padding: '6px 10px', fontSize: 12, color: s.text, width: 130 }} />
      <input type="password" placeholder="Nova" value={passForms.next} onChange={e => setPassForms(f => ({ ...f, next: e.target.value }))}
        style={{ background: '#231c08', border: '1px solid #3d3010', borderRadius: 6, padding: '6px 10px', fontSize: 12, color: s.text, width: 130 }} />
      <button onClick={changePassword} style={{ background: '#d4a017', color: '#0f0c00', fontSize: 12, fontWeight: 700, padding: '6px 14px', borderRadius: 6, border: 'none', cursor: 'pointer' }}>Spremi</button>
      {passError && <span style={{ fontSize: 12, color: '#f87171' }}>{passError}</span>}
      <button onClick={() => setShowSettings(false)} style={{ background: 'transparent', border: 'none', color: '#6b5a20', fontSize: 16, cursor: 'pointer', marginLeft: 'auto' }}>✕</button>
    </div>
  ) : null;

  const ErrorBar = () => apiError ? (
    <div style={{ background: '#1a0808', borderBottom: '1px solid #330a0a', padding: '8px 16px', fontSize: 12, color: '#f87171', display: 'flex', justifyContent: 'space-between', flexShrink: 0 }}>
      {apiError} <button onClick={() => setApiError('')} style={{ background: 'none', border: 'none', color: '#f87171', cursor: 'pointer' }}>✕</button>
    </div>
  ) : null;

  // ── MOBILE ────────────────────────────────────────────────────────────────
  if (isMobile) {
    const showDetail = !!(selectedId && proj);
    return (
      <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, display: 'flex', flexDirection: 'column', background: s.bg }}>
        <Header showBack={showDetail} />
        {SettingsBar()}
        {ErrorBar()}
        {!showDetail ? (
          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
            <div style={{ padding: '12px 16px', borderBottom: `1px solid ${s.border}`, flexShrink: 0 }}>
              <button onClick={() => { setShowNew(!showNew); if (!showNew) setNewForm({ name: '', clientName: '', accessCode: generateCode(), description: '' }); }}
                style={{ width: '100%', background: s.accent, color: 'white', border: 'none', borderRadius: 10, padding: '13px 0', fontSize: 14, fontWeight: 700, cursor: 'pointer' }}>
                + Novi projekt
              </button>
            </div>
            {showNew && <div style={{ overflowY: 'auto', borderBottom: `1px solid ${s.border}` }}>{NewProjectPanel()}</div>}
            {ProjectList()}
          </div>
        ) : (
          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
            {ProjectDetail()}
          </div>
        )}
      </div>
    );
  }

  // ── DESKTOP ───────────────────────────────────────────────────────────────
  return (
    <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, display: 'flex', flexDirection: 'column', background: s.bg }}>
      <Header showBack={false} />
      {SettingsBar()}
      {ErrorBar()}
      <div style={{ display: 'flex', flex: 1, overflow: 'hidden' }}>
        <div style={{ width: 235, background: s.sidebar, borderRight: `1px solid ${s.border}`, display: 'flex', flexDirection: 'column', flexShrink: 0 }}>
          <div style={{ padding: 10, flexShrink: 0 }}>
            <button onClick={() => { setShowNew(!showNew); if (!showNew) setNewForm({ name: '', clientName: '', accessCode: generateCode(), description: '' }); }}
              style={{ width: '100%', background: s.accent, color: 'white', border: 'none', borderRadius: 8, padding: '9px 0', fontSize: 12, fontWeight: 700, cursor: 'pointer' }}>
              + Novi projekt
            </button>
          </div>
          {showNew && <div style={{ overflowY: 'auto', borderBottom: `1px solid ${s.border}` }}>{NewProjectPanel()}</div>}
          {ProjectList()}
        </div>
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
          {!proj
            ? <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', flex: 1, flexDirection: 'column', gap: 8 }}><FolderIco /><p style={{ fontSize: 13, color: s.muted }}>Odaberi projekt</p></div>
            : ProjectDetail()
          }
        </div>
      </div>
    </div>
  );
}

function ClientView({ project, onLogout }) {
  const done = project.tasks.filter(t => t.done).length;
  const total = project.tasks.length;
  const pct = total > 0 ? Math.round((done / total) * 100) : 0;
  const s = { bg: '#0f1117', card: '#151921', border: '#1e2330', text: '#e2e8f0', muted: '#4a5568', green: '#22c55e' };

  return (
    <div style={{ minHeight: '100vh', background: s.bg }}>
      <div style={{ height: 52, borderBottom: `1px solid ${s.border}`, padding: '0 16px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', background: '#0d1018', position: 'sticky', top: 0 }}>
        <div style={{ flex: 1, minWidth: 0 }}>
          <p style={{ fontWeight: 700, fontSize: 15, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{project.name}</p>
          {project.client_name && <p style={{ fontSize: 12, color: s.muted }}>{project.client_name}</p>}
        </div>
        <button onClick={onLogout} style={{ background: 'transparent', border: 'none', fontSize: 12, color: s.muted, cursor: 'pointer', marginLeft: 12, flexShrink: 0 }}>Odjava</button>
      </div>
      <div style={{ maxWidth: 600, margin: '0 auto', padding: '20px 16px 60px' }}>
        <div style={{ background: s.card, border: `1px solid ${s.border}`, borderRadius: 14, padding: 20, marginBottom: 16 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
            <span style={{ fontSize: 14, fontWeight: 600 }}>Napredak projekta</span>
            <span style={{ fontSize: 24, fontWeight: 800, color: pct === 100 ? s.green : s.text }}>{pct}%</span>
          </div>
          <div style={{ height: 6, background: '#1e2330', borderRadius: 3, overflow: 'hidden' }}>
            <div style={{ width: `${pct}%`, height: '100%', background: pct === 100 ? s.green : 'linear-gradient(90deg,#3b82f6,#6366f1)', transition: 'width 0.5s', borderRadius: 3 }} />
          </div>
          <p style={{ fontSize: 12, color: s.muted, marginTop: 8 }}>{done} od {total} zadataka završeno</p>
          {project.description && <p style={{ fontSize: 13, color: '#5a6070', marginTop: 8, lineHeight: 1.5 }}>{project.description}</p>}
          {pct === 100 && total > 0 && <p style={{ fontSize: 14, color: s.green, marginTop: 10, fontWeight: 700 }}>Sve je gotovo!</p>}
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {total === 0 && <div style={{ background: s.card, border: `1px dashed ${s.border}`, borderRadius: 12, padding: 40, textAlign: 'center' }}><p style={{ fontSize: 13, color: s.muted }}>Zadaci još nisu dodani.</p></div>}
          {project.tasks.map(task => (
            <div key={task.id} style={{ background: task.done ? '#0d1a12' : s.card, border: `1px solid ${task.done ? '#1a3025' : s.border}`, borderRadius: 12, padding: '14px 16px' }}>
              <div style={{ display: 'flex', alignItems: 'flex-start', gap: 12 }}>
                <div style={{ width: 22, height: 22, borderRadius: 6, flexShrink: 0, border: `2px solid ${task.done ? s.green : '#2a3245'}`, background: task.done ? s.green : 'transparent', display: 'flex', alignItems: 'center', justifyContent: 'center', marginTop: 2, color: 'white' }}>
                  {task.done && <CheckIco />}
                </div>
                <div style={{ flex: 1 }}>
                  <p style={{ fontSize: 15, color: task.done ? s.muted : s.text, textDecoration: task.done ? 'line-through' : 'none', lineHeight: 1.5 }}>{task.text}</p>
                  {task.note && <p style={{ fontSize: 13, color: '#60a5fa', marginTop: 7, background: '#0f1e35', padding: '8px 12px', borderRadius: 7, borderLeft: '2px solid #3b82f6', lineHeight: 1.5 }}>{task.note}</p>}
                </div>
                <span style={{ fontSize: 12, padding: '4px 10px', borderRadius: 20, flexShrink: 0, background: task.done ? '#0d2516' : '#1e2330', color: task.done ? s.green : s.muted, fontWeight: 500 }}>
                  {task.done ? 'Gotovo' : 'Čeka'}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
